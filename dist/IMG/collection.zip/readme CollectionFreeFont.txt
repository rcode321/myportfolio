we hope you enjoy this font. If you need an extended license or corporate license, please contact me at displayart20@gmail.com :)

NOTE: This demo font is for PERSONAL USE ONLY! But any donation are very appreciated. 

Paypal account for donation : https://www.paypal.me/agungr

Link to purchase full version and commercial license: https://crmrkt.com/w76yNm

Thank you,
Best regards
alphArt